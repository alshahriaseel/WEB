from django.urls import path
from . import views

urlpatterns = [
    path('',views.login_page,name='login'),
    path('register',views.register,name='register'),
    path('all_products/', views.all_products, name='all_products'),
    path('<int:product_id>',views.product_details,name="product_details"),
    path('Basket',views.Basket,name='Basket'),
    path('order_page', views.order_page, name='order_page'),
    path('logout_page', views.logout_page,name='logout_page')
]
