from django.shortcuts import render
from django.urls import reverse
from .models import Product,OrderdProduct,Order,OrderItem
from django.http import HttpResponseRedirect,HttpResponse
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User

def login_page(request):
    message=""
    if request.method=="POST":
        username=request.POST["username"]
        password=request.POST["password"]
        user=authenticate(request,username=username,password=password)
        if user:
            login(request,user)
            return HttpResponseRedirect(reverse('all_products'))
        else:
         message="Incorrect password."
    return render(request, "zarashop/login.html", {"message": message})
        
def register(request):
    message = ""

    if request.method == "POST":
        full_name = request.POST.get("full_name")
        email = request.POST.get("email")
        username = request.POST.get("username")
        password = request.POST.get("password")

        if User.objects.filter(username=username).exists():
            message = "This username is already taken."
        else:
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password
            )
            user.save()
            message = "Account created successfully."
    return render(request, "zarashop/register.html", {
        "message": message
    })
def logout_page(request):
    logout(request)
    return render(request,"zarashop/login.html")

def all_products(request):
    products = Product.objects.all()
    return render(request, "zarashop/all_products.html", {"products": products})

def product_details(request,product_id):
    product=Product.objects.get(id=product_id)
    if request.method == "POST":
        amount=int(request.POST["amount"])
        ordered_product=OrderdProduct.objects.create(user=request.user,selected_product=product,amount=amount)
        return HttpResponseRedirect(reverse('Basket'))
    
    return render(request,"zarashop/product_details.html",{
        "product":product
                 })

def Basket(request):
    
    items = OrderdProduct.objects.all()   

    if request.method == "POST":

        # Empty basket
        if "empty_basket" in request.POST:
            items.delete()
            return HttpResponseRedirect(reverse("Basket"))

        # Update amount
        if "update_basket" in request.POST:
            for item in items:
                field_name = f"amount_{item.id}"
                new_amount = request.POST.get(field_name)

                if new_amount is None or new_amount == "":
                    continue

                try:
                    new_amount = int(new_amount)
                except ValueError:
                    continue

                if new_amount <= 0:
                    item.delete()
                else:
                    item.amount = new_amount
                    item.save()

            return HttpResponseRedirect(reverse("Basket"))


    items = OrderdProduct.objects.all()

    
    basket_items = []
    total_cost = 0
    for item in items:
        total = item.selected_product.price * item.amount
        total_cost += total
        basket_items.append({
            "id": item.id,
            "product": item.selected_product,
            "amount": item.amount,
            "price": item.selected_product.price,
            "total": total,
        })


    return render(request, "zarashop/basket.html", {
        "items": basket_items,
        "total_cost": total_cost,
    })


def order_page(request):
    basket_items = OrderdProduct.objects.all()  
    items = []
    total_basket_cost = 0
    for item in basket_items:
        product_total_price = item.selected_product.price * item.amount
        total_basket_cost += product_total_price
        items.append({
            "product" : item.selected_product,
            "amount" : item.amount,
            "price" : item.selected_product.price,
            "total" : product_total_price,
        })

    if request.method == "POST":
        order = Order.objects.create(user=request.user,total_price = total_basket_cost)

        for item in basket_items:
            OrderItem.objects.create(order=order,product=item.selected_product,amount=item.amount)
    
        basket_items.delete()
        return HttpResponseRedirect(reverse("all_products"))

    return render(request, "zarashop/order_page.html", {
        "items": items,
        "total_basket_cost": total_basket_cost,
    })

        



   
