from django.db import models
from django.contrib.auth.models import User

class Product(models.Model):
    name = models.TextField(max_length=60)
    description = models.TextField(max_length=200)
    price = models.FloatField()
    image = models.ImageField(upload_to='products/')

    def __str__(self):
        return self.name


class OrderdProduct(models.Model):
    amount=models.IntegerField()
    user=models.ForeignKey(User, on_delete=models.CASCADE)
    selected_product=models.ForeignKey(Product, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.selected_product} {self.amount}"


class Order(models.Model):
    user=models.ForeignKey(User, on_delete=models.CASCADE)
    total_price=models.FloatField()

    def __str__(self):
        return f"Order#{self.id}, customer name: {self.user.username}"
    
class OrderItem(models.Model):
    order= models.ForeignKey(Order, on_delete=models.CASCADE)
    product= models.ForeignKey(Product, on_delete=models.CASCADE)
    amount=models.IntegerField()
    

    def __str__(self):
        return f"Order#{self.order.id}, product name:{self.product.name}, amount: {self.amount}"


    
    
    


