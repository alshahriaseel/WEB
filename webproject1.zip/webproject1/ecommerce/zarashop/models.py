from django.db import models

class Product(models.Model):
    name = models.TextField(max_length=60)
    description = models.TextField(max_length=200)
    price = models.FloatField()
    image = models.ImageField(upload_to='products/')

    def __str__(self):
        return self.name
    
class OrderdProduct(models.Model):
    amount=models.IntegerField()
    selected_product=models.ForeignKey(Product, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.selected_product} {self.amount}"


