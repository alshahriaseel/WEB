from django.shortcuts import render
from django.urls import reverse
from .models import Product,OrderdProduct
from django.http import HttpResponseRedirect,HttpResponse
def all_products(request):
    products = Product.objects.all()
    return render(request, "zarashop/all_products.html", {"products": products})

def product_details(request,product_id):
    product=Product.objects.get(id=product_id)
    if request.method == "POST":
        amount=int(request.POST["amount"])
        ordered_product=OrderdProduct.objects.create(selected_product=product,amount=amount)
        return HttpResponseRedirect(reverse('Basket'))
    
    return render(request,"zarashop/product_details.html",{
        "product":product
                 })

def Basket(request):
    return HttpResponse("Basket Page")
