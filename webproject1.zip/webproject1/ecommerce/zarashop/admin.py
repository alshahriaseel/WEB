from django.contrib import admin
from .models import Product,OrderdProduct

admin.site.register(Product)
admin.site.register(OrderdProduct)
