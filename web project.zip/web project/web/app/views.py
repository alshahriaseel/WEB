from django.shortcuts import render, redirect
from django.contrib.auth.models import User

def login(request):
    invalid = ""

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        try:
            user = User.objects.get(username=username)

            if user.check_password(password):
                request.session["user_id"] = user.id
                return redirect("login") 
            else:
                invalid = "Incorrect password."
        except User.DoesNotExist:
            invalid = "User does not exist."

    return render(request, "app/login.html", {
        "invalid": invalid
    })


def register(request):
    invalid = ""
    valid = ""

    if request.method == "POST":
        full_name = request.POST.get("full_name")
        email = request.POST.get("email")
        username = request.POST.get("username")
        password = request.POST.get("password")

        if User.objects.filter(username=username).exists():
            invalid = "This username is already taken."
        else:
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password
            )
            user.save()

            valid = "Account created successfully."

    return render(request, "app/register.html", {
        "invalid": invalid,
        "valid": valid
    })
